
public class Warriors {
	private String name,race;
	private int hp,str,def,dex,spe;	
}
