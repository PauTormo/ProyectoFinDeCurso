import java.util.ArrayList;

public class WeaponContainer {
	private ArrayList<Weapons> wp=new ArrayList<Weapons>();
	
}
