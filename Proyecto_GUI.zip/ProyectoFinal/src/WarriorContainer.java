import java.util.ArrayList;

public class WarriorContainer {
	private ArrayList<Warriors> wp=new ArrayList<Warriors>();
}
