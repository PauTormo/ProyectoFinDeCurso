
import java.sql.Connection;
import java.sql.DriverManager;

import java.sql.SQLException;



import Gui_Panels.Main_Window;

public class Proyecto_Main {
	public static void main(String[] args) {
		try {
			// Connect to the BDD
			String bdd="project";
			String url="jdbc:mysql://localhost/"+bdd+"?serverTimezone=UTC";
			String user="root";
			String pass="admin";
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection(url, user, pass);
			
			//Start Graphic Interface
			new Main_Window();
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}



