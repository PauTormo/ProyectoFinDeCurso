package Gui_Panels;


import java.awt.GridLayout;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;


public class Character_Window extends JFrame{
	JButton img,img2,img3,img4,img5,img6,img7,img8,img9;
	public Character_Window() {
		setLayout(new GridLayout(3,3));
		setSize(900,750);
		
		Image imagen = new ImageIcon("imagenes/Weapons/DoubleDagger.png").getImage();
		ImageIcon imagen2 = new ImageIcon(imagen.getScaledInstance(300, 250, Image.SCALE_SMOOTH));
		img=new JButton(imagen2);
		img.getPreferredSize();
		add(img);
		
		
		img2=new JButton(imagen2);
		img2.getPreferredSize();
		add(img2);
		
		img3=new JButton(imagen2);
		img3.getPreferredSize();
		add(img3);
		
		img4=new JButton(imagen2);
		img4.getPreferredSize();
		add(img4);
		
		img5=new JButton(imagen2);
		img5.getPreferredSize();
		add(img5);
		
		img6=new JButton(imagen2);
		img6.getPreferredSize();
		add(img6);
		
		img7=new JButton(imagen2);
		img7.getPreferredSize();
		add(img7);
		
		img8=new JButton(imagen2);
		img8.getPreferredSize();
		add(img8);
		
		img9=new JButton(imagen2);
		img9.getPreferredSize();
		add(img9);
		
		setVisible(true);
	}
}
