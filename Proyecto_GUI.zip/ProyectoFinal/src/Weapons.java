
public class Weapons {
	private String name;
	 
}
