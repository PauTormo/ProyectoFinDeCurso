import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class WeaponContainer {
	private ArrayList<Weapons> aw=new ArrayList<Weapons>();
	WeaponContainer(){
		
	}
	public ArrayList<Weapons> createWeaponsContainer(ConnectionBDD connection, Warriors c) {
		// 1.- llegir la base de dades y carregar els personatges
			Weapons weapon;
				try {
					Statement stm = connection.getCon().createStatement();
					String query = "Select weapon_id, weapon_name, weapon_image_path, strength ,speed, weapon_race ,points \n"
							+ " from weapons where weapon_race like '%" + c.getRaceName() + "%'";
					ResultSet rs = stm.executeQuery(query);
					System.out.println(c.getRaceName());
			        while(rs.next()){
			        	weapon = new Weapons();
			        	weapon.setIdWeapon(rs.getInt(1));
			        	weapon.setWeaponName(rs.getString(2));
			        	weapon.setWeaponImagePath(rs.getString(3));
			        	weapon.setStrength(rs.getInt(4));
			        	weapon.setSpeed(rs.getInt(5));
			        	weapon.setWeaponRace(rs.getString(6));
			        	weapon.setPoints(rs.getInt(7));
			            aw.add(weapon);
			        }
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				

		return aw;
	}
}
