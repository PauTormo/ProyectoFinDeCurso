import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;


public class Weapon_Window extends JFrame implements ActionListener{

	JButton images[];
	String weaponSelect="";
	public Weapon_Window(ArrayList<Weapons> aw) {
		setLayout(new GridLayout(3,3));
		setSize(900,750);
		
		images=new JButton[9];
		int i=0;

		for(Weapons w : aw) {
			
			Image image = new ImageIcon("imagenes"+File.separator+"Weapons"+File.separator+w.getWeaponImagePath()).getImage();
			ImageIcon imageC1 = new ImageIcon(image.getScaledInstance(300, 250, Image.SCALE_SMOOTH));
			images[i]=new JButton(imageC1);
			images[i].getPreferredSize();
			add(images[i]);	
			images[i].setName(w.getWeaponName());
			images[i].addActionListener(this);
			i++;
		}
		setVisible(true);
	}

public void actionPerformed(ActionEvent e) {
    if (e.getSource()==images[0]) {
    	weaponSelect=images[0].getName();
    }
    if (e.getSource()==images[1]) {
    	weaponSelect=images[1].getName(); 
    }
    if (e.getSource()==images[2]) {
    	weaponSelect=images[2].getName();
    }
    if (e.getSource()==images[3]) {
    	weaponSelect=images[3].getName(); 
    }
    if (e.getSource()==images[4]) {
    	weaponSelect=images[4].getName();
    }
    if (e.getSource()==images[5]) {
    	weaponSelect=images[5].getName(); 
    }
    if (e.getSource()==images[6]) {
    	weaponSelect=images[6].getName();
    }
    if (e.getSource()==images[7]) {
    	weaponSelect=images[7].getName(); 
    }	
    if (e.getSource()==images[8]) {
    	weaponSelect=images[8].getName(); 
    }		        
}


public String getValor() {
 return weaponSelect;
	}
}