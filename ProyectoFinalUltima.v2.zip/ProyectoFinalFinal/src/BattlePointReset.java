//import java.awt.BorderLayout;
//import java.awt.event.ActionEvent;
//import java.awt.event.ActionListener;
//
//import javax.swing.JButton;
//import javax.swing.JFrame;
//import javax.swing.JPanel;
//import javax.swing.JTextArea;
//
//public class BattlePointReset extends JFrame{
//		JPanel panelUp,panelCen;
//		JTextArea txt;
//		JButton confirm,exit;
//		public void battlePointReset() {
//			panelUp=new JPanel();
//			panelCen=new JPanel();
//			confirm=new JButton("Confirm");
//			exit=new JButton("Cancel");
//			txt=new JTextArea("If you change the character now, your battle point will be restarted\\n Are you sure to continue?");
//			panelUp.add(txt);
//			confirm.addActionListener(new ActionListener() {
//				@Override
//				public void actionPerformed(ActionEvent arg0) {
//					con.setRanking(con.getUserId(),btl_pnt,w1);
//					btl_pnt=0;
//					dispose();
//					
//				}
//				
//			});
//			exit.addActionListener(new ActionListener() {
//				@Override
//				public void actionPerformed(ActionEvent arg0) {
//					dispose();
//				}
//				
//			});
//			panelCen.add(confirm);
//			panelCen.add(exit);
//			add(panelUp,BorderLayout.NORTH);
//			add(panelCen,BorderLayout.CENTER);
//			setSize(300,300);
//			setVisible(true);
//		}
//	}
