import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRootPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class Ranking  extends JFrame{
	JPanel panelUp,panelCen,panelLInv;
	JTextArea tplayer,tpoints,twar,title;
	JTextArea player,points,war;
	JScrollPane scroll;
	
	GridLayout grid;
	public Ranking(ConnectionBDD connection) {
		panelUp = new JPanel();
		panelLInv = new JPanel();
		panelLInv.setOpaque(true);
		panelLInv.setPreferredSize(new Dimension(210,0));
		grid = new GridLayout(6,3);
		panelUp.setPreferredSize(new Dimension(150,100));
		grid.setHgap(-50);
		grid.setVgap(-100);
		panelCen = new JPanel(grid);
		
		title = new JTextArea("Ranking");
		title.setFont(new Font("Monospaced",Font.PLAIN,50));
		title.setOpaque(false);
		title.setBackground(new Color(255,255,255,255));
		tplayer = new JTextArea("Player Id");
		tplayer.setOpaque(false);
		tplayer.setBackground(new Color(255,255,255,255));
		tpoints = new JTextArea("Points");
		tpoints.setOpaque(false);
		tpoints.setBackground(new Color(255,255,255,255));
		twar = new JTextArea("Warrior Id");
		
		twar.setOpaque(false);
		twar.setBackground(new Color(255,255,255,255));
		
		
		panelCen.add(tplayer);
		panelCen.add(tpoints);
		panelCen.add(twar);

		try {
			
			Statement stm = connection.getCon().createStatement();
			String query = "select * from ranking order by total_points desc limit 5;";
			ResultSet rs = stm.executeQuery(query);
	        while (rs.next()) {
	        	player = new JTextArea();
	    		player.setOpaque(false);
	    		player.setBackground(new Color(255,255,255,255));
	    		points = new JTextArea();
	    		points.setOpaque(false);
	    		points.setBackground(new Color(255,255,255,255));
	    		war = new JTextArea();
	    		war.setOpaque(false);
	    		war.setBackground(new Color(255,255,255,255));
	        	player.setText(String.valueOf(rs.getInt(1)));
	        	points.setText(String.valueOf(rs.getInt(2)));
	        	war.setText(String.valueOf(rs.getInt(3)));
	        	panelCen.add(player);
	    		panelCen.add(points);
	    		panelCen.add(war);
	        }
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		panelUp.add(title);
		
		
		add(panelUp,BorderLayout.NORTH);
		add(panelLInv,BorderLayout.WEST);
		add(panelCen,BorderLayout.CENTER);
		
		setSize(900,750);
		setVisible(true);
	}
}

