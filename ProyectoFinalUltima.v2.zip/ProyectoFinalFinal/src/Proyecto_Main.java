
import java.sql.Connection;
import java.sql.DriverManager;

import java.sql.SQLException;

public class Proyecto_Main {
	public static void main(String[] args) {
		String name="";	

		User us=new User();
		ConnectionBDD connection=new ConnectionBDD();
		name = us.name;
		System.out.println(name);

		
		
		
		
		
		
		
		new Main_Window();
			
	}
}



