import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class User extends JFrame{
	JFrame f;
	ConnectionBDD con;
	String name;
	public User() {
		con=new ConnectionBDD();
		f=new JFrame();   
	    name=JOptionPane.showInputDialog(f,"Enter Name","Guest");
	    if (name==null || name.equalsIgnoreCase("")) {
			name="Guest";
		}
	    con.saveUser(name);
	    
	}
}