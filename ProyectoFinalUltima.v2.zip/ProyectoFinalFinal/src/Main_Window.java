

import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.File;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

//Main window of Graphic interface
public class Main_Window extends JFrame implements WindowListener{
	ConnectionBDD con;
//	BattlePointReset battlePointReset;
	JPanel panelcen;
	PanelUp panelUp;
	PanelInf panelInf;
	PanelCenL panelCenL;
	PanelCenR panelCenR;
	PanelCenInf panelCenInf;
	WarriorContainer warriorsContainer;
	Warriors warriors[];
	WeaponContainer weaponsContainer;
	Weapons weapons[];	
	Fight_Main fight_main;
	Ranking ranking;
	ArrayList<Integer> btl_id;
	private ArrayList<Weapons> aw;
	private ArrayList<Weapons> aw2;
	private ArrayList<Warriors> wp;
	Character_Window cw;
	Weapon_Window ww;
	Ranking rk;
	Warriors w1,w2,winner,loser;
	Weapons wea1,wea2,winnerwea;
	Boolean cho_war;
	int btl_pnt;
	public Main_Window() {
		con= new ConnectionBDD();
		btl_id = new ArrayList<Integer>();
        warriors= new Warriors[2];
//        battlePointReset=new BattlePointReset();
		panelUp = new PanelUp();
		panelcen = new JPanel(new BorderLayout());
		panelInf = new PanelInf();
		wp=new ArrayList<Warriors>();
		aw= new ArrayList<Weapons>();
		weaponsContainer = new WeaponContainer();
		warriorsContainer = new WarriorContainer();
		setResizable(false);
		wp= warriorsContainer.createWarriorContainer(con);

		
		panelCenL = new PanelCenL();
		panelCenR = new PanelCenR();
		panelCenInf = new PanelCenInf();
		panelCenL.setOpaque(true);
		panelCenR.setOpaque(true);
		panelCenInf.setOpaque(true);
		panelCenL.setBackground(new Color(220,220,220));
		panelCenR.setBackground(new Color(220,220,220));
		panelCenInf.setBackground(new Color(220,220,220));
		
		
		
		
		panelUp.chochar.addActionListener (
				new ActionListener() {

					@Override
					public void actionPerformed(ActionEvent arg0) {
							cw= new Character_Window(wp);
							if (btl_pnt>0) {
								int input = JOptionPane.showOptionDialog(null,"If you change the character now, your battle point will be restarted\n Are you sure to continue?", "Continue?",
									JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null,null,null);
								if (input==0) {
									
									con.setRanking(con.getUserId(),btl_pnt,winner);
									btl_pnt=0;
								}else {
									cw.dispose();
									setEnabled(true);
								}
							}
							cw.addWindowListener(new WindowAdapter() {
									
							@Override
							public void windowClosing(WindowEvent e) {
								
								int i = 0;
								int numAleatorio = (int) (Math.random()*9);
								for(Warriors c  : warriorsContainer.getWp()) {
									if (c.getName().equals(cw.getValor())) {
										if (wea1==null) {
											Image imagen = new ImageIcon("imagenes"+File.separator+"Warriors"+File.separator+c.getImagePath()).getImage();
											ImageIcon imagen2 = new ImageIcon(imagen.getScaledInstance(400, 390, Image.SCALE_SMOOTH));
											panelCenL.img.setIcon(imagen2);
											panelCenL.panelCenLInf.str.setValue(c.getStrength());
											panelCenL.panelCenLInf.agi.setValue(c.getAgility());
											panelCenL.panelCenLInf.spd.setValue(c.getSpeed());
											panelCenL.panelCenLInf.def.setValue(c.getDefense());
											w1=c;
										}else {
											Image imagen = new ImageIcon("imagenes"+File.separator+"Warriors"+File.separator+c.getImagePath()).getImage();
											ImageIcon imagen2 = new ImageIcon(imagen.getScaledInstance(400, 390, Image.SCALE_SMOOTH));
											panelCenL.img.setIcon(imagen2);
											panelCenL.panelCenLInf.str.setValue(c.getStrength());
											panelCenL.panelCenLInf.agi.setValue(c.getAgility());
											panelCenL.panelCenLInf.spd.setValue(c.getSpeed());
											panelCenL.panelCenLInf.def.setValue(c.getDefense());
											w1=c;
											
											Image image = new ImageIcon("imagenes"+File.separator+"interrogacion.jpg").getImage();
											ImageIcon image2 = new ImageIcon(image.getScaledInstance(75, 75, Image.SCALE_SMOOTH));
											panelCenL.panelCenLInf.img.setIcon(image2);
											wea1=null;
											Image image3 = new ImageIcon("imagenes"+File.separator+"interrogacion.jpg").getImage();
											ImageIcon image4= new ImageIcon(image.getScaledInstance(75, 75, Image.SCALE_SMOOTH));
											panelCenR.panelCenRInf.img.setIcon(image2);
											wea2=null;
										}
										
									}
									if (i==numAleatorio) {
										Image imagen = new ImageIcon("imagenes"+File.separator+"Warriors"+File.separator+c.getImagePath()).getImage();
										ImageIcon imagen2 = new ImageIcon(imagen.getScaledInstance(400, 390, Image.SCALE_SMOOTH));
										panelCenR.img.setIcon(imagen2);
										panelCenR.panelCenRInf.str.setValue(c.getStrength());
										panelCenR.panelCenRInf.agi.setValue(c.getAgility());
										panelCenR.panelCenRInf.spd.setValue(c.getSpeed());
										panelCenR.panelCenRInf.def.setValue(c.getDefense());
										w2=new Warriors(c.getName(),c.getRaceName(),c.getHp(),c.getStrength(),c.getSpeed(),c.getAgility(),c.getDefense(),c.getPoints(),c.getId(),c.getImagePath());
										
										
										
										
									}
									i++;
								}
								
								
							}	
							
						});
						cw.setAlwaysOnTop(true);
						setEnabled(false);
						cw.addWindowListener(
								new WindowAdapter() {
			
									@Override
									public void windowClosing(WindowEvent arg0) {
										setEnabled(true);
										panelUp.choweap.setEnabled(true);
									}

									@Override
									public void windowClosed(WindowEvent arg0) {
										setEnabled(true);
										
									}

								}	
							);
						
						}
					
					});
		
		
		panelUp.choweap.addActionListener (
				new ActionListener() {

					@Override
					public void actionPerformed(ActionEvent arg0) {
						aw=weaponsContainer.createWeaponsContainer(con,w1);
						ww= new Weapon_Window(aw);
						ww.setAlwaysOnTop(true);
						setEnabled(false);
						
						ww.addWindowListener(
								new WindowAdapter() {
								
									@Override
									public void windowClosing(WindowEvent arg0) {								
										
										
										

										for(Weapons w  : weaponsContainer.getAw()) {
											
											if (w.getWeaponName().equals(ww.getValor())) {
													Image image = new ImageIcon("imagenes"+File.separator+"Weapons"+File.separator+w.getWeaponImagePath()).getImage();
													ImageIcon image2 = new ImageIcon(image.getScaledInstance(75, 75, Image.SCALE_SMOOTH));
													panelCenL.panelCenLInf.img.setIcon(image2);
													panelCenL.panelCenLInf.str.setValue(w1.getStrength()+w.getStrength());
													panelCenL.panelCenLInf.spd.setValue(w1.getSpeed()+w.getSpeed());
													wea1 = w;
												
											}
										}
										
										aw2=weaponsContainer.createWeaponsContainer(con,w2);
										
										int numAleatorio = (int) (Math.random()*aw2.size());
										 
										Image imagen = new ImageIcon("imagenes"+File.separator+"Weapons"+File.separator+aw2.get(numAleatorio).getWeaponImagePath()).getImage();
										ImageIcon imagen2 = new ImageIcon(imagen.getScaledInstance(75, 75, Image.SCALE_SMOOTH));
										panelCenR.panelCenRInf.img.setIcon(imagen2);
										panelCenR.panelCenRInf.str.setValue(w2.getStrength()+aw2.get(numAleatorio).getStrength());
										panelCenR.panelCenRInf.spd.setValue(w2.getSpeed()+aw2.get(numAleatorio).getSpeed());
										wea2 = aw2.get(numAleatorio);			
										
										
										
										setEnabled(true);
										
									}
								}	
								);
					}
					
				});
		panelUp.choweap.setEnabled(false);
		
		panelCenInf.fight.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				try {
					fight_main=new Fight_Main(w1,w2,wea1,wea2,panelCenL.hp_bar,panelCenR.hp_bar,panelInf.cmndline,con,btl_pnt);
					btl_pnt+=fight_main.btle_pnt;
					  
					if (w1.getHp()>0) {
						winner=w1;
						winnerwea=wea1;
						loser=w2;
					}else {
						winner=w2;
						loser=w1;
						winnerwea=wea2;
					}
					if (loser.getName().equalsIgnoreCase(w1.getName())) {
						btl_pnt=0;
					}
					Object[] choices = {"Play Again", "Exit"};
					Object defaultChoice = choices[0];
					int input = JOptionPane.showOptionDialog(null,winner.getName()+"!!!\n"+ winner.getName()+" has defet "+loser.getName()+"\nDo you want to continue?", "The winner is...",
							JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null,choices,defaultChoice);
					int i = 0;
					int numAleatorio = (int) (Math.random()*9);
					if (input==0){
						panelCenL.hp_bar.setValue(100);
						panelCenR.hp_bar.setValue(100);
						wp=new ArrayList<Warriors>();
						wp= warriorsContainer.createWarriorContainer(con);
						if (w1.getRaceName().equalsIgnoreCase("Elf")) {
							w1.setHp(40);
						}else if(w1.getRaceName().equalsIgnoreCase("Human")) {
							w1.setHp(50);
						}else if(w1.getRaceName().equalsIgnoreCase("Dwarf")) {
							w1.setHp(60);
						}
						if (w2.getRaceName().equalsIgnoreCase("Elf")) {
							w2.setHp(40);
						}else if(w2.getRaceName().equalsIgnoreCase("Human")) {
							w2.setHp(50);
						}else if(w2.getRaceName().equalsIgnoreCase("Dwarf")) {
							w2.setHp(60);
						}
						panelUp.choweap.setEnabled(false);
						
						
						for(Warriors c  : warriorsContainer.getWp()) {
							if (i==numAleatorio) {
								Image imagen = new ImageIcon("imagenes"+File.separator+"Warriors"+File.separator+c.getImagePath()).getImage();
								ImageIcon imagen2 = new ImageIcon(imagen.getScaledInstance(400, 390, Image.SCALE_SMOOTH));
								panelCenR.img.setIcon(imagen2);
								panelCenR.panelCenRInf.str.setValue(c.getStrength());
								panelCenR.panelCenRInf.agi.setValue(c.getAgility());
								panelCenR.panelCenRInf.spd.setValue(c.getSpeed());
								panelCenR.panelCenRInf.def.setValue(c.getDefense());
								w2=new Warriors(c.getName(),c.getRaceName(),c.getHp(),c.getStrength(),c.getSpeed(),c.getAgility(),c.getDefense(),c.getPoints(),c.getId(),c.getImagePath());
							}
							i++;
						}
					}
					else if (input==-1) {
						w1=null;
						w2=null;
						wea1=null;
						wea2=null;
						panelUp.choweap.setEnabled(false);
						panelCenL.hp_bar.setValue(100);
						panelCenR.hp_bar.setValue(100);
						
						wp=new ArrayList<Warriors>();
						wp= warriorsContainer.createWarriorContainer(con);
						
						Image imagen = new ImageIcon("imagenes"+File.separator+"interrogacion.jpg").getImage();
						ImageIcon imagen2 = new ImageIcon(imagen.getScaledInstance(65, 50, Image.SCALE_SMOOTH));
						panelCenR.panelCenRInf.img.setIcon(imagen2);
						panelCenL.panelCenLInf.img.setIcon(imagen2);
						Image imagen5 = new ImageIcon("imagenes"+File.separator+"interrogacion.jpg").getImage();
						ImageIcon imagen6 = new ImageIcon(imagen.getScaledInstance(400, 380, Image.SCALE_SMOOTH));
						panelCenL.img.setIcon(imagen6);
						panelCenR.img.setIcon(imagen6);
						
						panelCenL.panelCenLInf.str.setValue(100);
						panelCenL.panelCenLInf.agi.setValue(100);
						panelCenL.panelCenLInf.spd.setValue(100);
						panelCenL.panelCenLInf.def.setValue(100);
						panelCenR.panelCenRInf.str.setValue(100);
						panelCenR.panelCenRInf.agi.setValue(100);
						panelCenR.panelCenRInf.spd.setValue(100);
						panelCenR.panelCenRInf.def.setValue(100);
						// GUARDAR INFORMACION DEL COMBATE ANTERIOR
					}else if(input==1) {
						dispose();
					}
					
				}catch (NullPointerException e) {
					panelInf.cmndline.append("To start the fight, you need to select a Warrior and Weapon.\n");
				}		
				
			}
			
		});
		
		panelCenInf.clear.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				panelInf.cmndline.setText("");
				
			}
			
		});
		panelUp.ranking.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				ranking=new Ranking(con);
				ranking.setAlwaysOnTop(true);
				setEnabled(false);
				ranking.addWindowListener(
						new WindowAdapter() {
							@Override
							public void windowClosing(WindowEvent arg0) {								
								setEnabled(true);
							}
						}	
						);
			}
			
		});
		
		setSize(900,750);
		panelcen.setOpaque(true);
		panelUp.setOpaque(true);
		panelInf.setOpaque(true);
		panelcen.setBackground(new Color(220,220,220));
		panelUp.setBackground(new Color(220,220,220));
		panelInf.setBackground(new Color(220,220,220));
		
		add(panelcen,BorderLayout.CENTER);
		panelcen.add(panelCenL,BorderLayout.WEST);
		panelcen.add(panelCenR,BorderLayout.EAST);
		panelcen.add(panelCenInf,BorderLayout.SOUTH);
		add(panelUp,BorderLayout.NORTH);
		add(panelInf,BorderLayout.SOUTH);
		
		setVisible(true);
		
	}

	@Override
	public void windowOpened(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowClosing(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowClosed(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowIconified(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowDeiconified(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowActivated(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowDeactivated(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	
	
}


//Superior panel of Main window "Main_Window"
class PanelUp extends JPanel{
	JButton chochar,choweap,ranking;
	public PanelUp() {
		chochar = new JButton("Choose Character");
		choweap = new JButton("Choose Weapon");
		ranking = new JButton("Ranking");
		add(chochar);
		add(choweap);
		add(ranking);
	}
}

//Center Panel
//Left panel of Center Panel of Main Window "Main_Window"
class PanelCenL extends JPanel{
	JLabel img;
	JProgressBar hp_bar;
	PanelCenLInf panelCenLInf;
	public PanelCenL() {
		panelCenLInf = new PanelCenLInf();
		panelCenLInf.setSize(200, 200);
		setLayout(new BorderLayout());
		Image imagen = new ImageIcon("imagenes"+File.separator+"interrogacion.jpg").getImage();
		ImageIcon imagen2 = new ImageIcon(imagen.getScaledInstance(400, 380, Image.SCALE_SMOOTH));
		img=new JLabel(imagen2);
		img.getPreferredSize();
		
		panelCenLInf.setOpaque(true);
		panelCenLInf.setBackground(new Color(220,220,220));
		
		hp_bar = new JProgressBar(0,100);
		hp_bar.setPreferredSize(new Dimension(400,80));
		hp_bar.setValue(100);
		hp_bar.setForeground(Color.green);
		hp_bar.setStringPainted(true);
		
		setSize(420,500);
		add(hp_bar,BorderLayout.NORTH);
		add(img,BorderLayout.CENTER);
		add(panelCenLInf,BorderLayout.SOUTH);
	}
}
class PanelCenLInf extends JPanel{
	JPanel izq,der,cen;
	JLabel img;
	JList statsname, stats;
	JProgressBar str,def,agi,spd;
	public PanelCenLInf() {
		
		setSize(200, 200);
		izq = new JPanel();
		cen = new JPanel();
		der = new JPanel(new GridLayout(4,1));
		
		String[] info= {"Power","Agility","Speed","Defense"}; 
		statsname=new JList(info);
		
		statsname.setBackground(new Color(220,220,220));
		Image imagen = new ImageIcon("imagenes"+File.separator+"interrogacion.jpg").getImage();
		ImageIcon imagen2 = new ImageIcon(imagen.getScaledInstance(65, 50, Image.SCALE_SMOOTH));
		img=new JLabel(imagen2);
		img.getPreferredSize();
	
		izq.setOpaque(true);
		izq.setBackground(new Color(220,220,220));
		der.setOpaque(true);
		der.setBackground(new Color(220,220,220));
		cen.setOpaque(true);
		cen.setBackground(new Color(220,220,220));
		cen.setPreferredSize(new Dimension(100,0));
		izq.add(img);
		izq.add(statsname);
		
	
		
		str = new JProgressBar(0,11);
		str.setPreferredSize(new Dimension(140,18));
		str.setValue(5);
		str.setStringPainted(false);
		str.setForeground(Color.red);

		agi = new JProgressBar(0,11);
		agi.setPreferredSize(new Dimension(140,18));
		agi.setValue(5);
		agi.setStringPainted(false);
		agi.setForeground(new Color(153,50,204));
		
		def = new JProgressBar(0,11);
		def.setPreferredSize(new Dimension(140,18));
		def.setValue(5);
		def.setStringPainted(false);
		def.setForeground(Color.blue);
		
		spd = new JProgressBar(0,11);
		spd.setPreferredSize(new Dimension(140,18));
		spd.setValue(5);
		spd.setStringPainted(false);
		spd.setForeground(Color.yellow);
		
		der.add(str);
		der.add(agi);
		der.add(def);
		der.add(spd);
		
		
		add(izq,BorderLayout.WEST);
		add(cen,BorderLayout.CENTER);
		add(der,BorderLayout.EAST);
	}
}
//Right panel of Center Panel of Main Window "panelcen"
class PanelCenR extends JPanel{
	JLabel img;
	JProgressBar hp_bar;
	PanelCenRInf panelCenRInf;
	public PanelCenR() {
		panelCenRInf = new PanelCenRInf();
		panelCenRInf.setSize(200, 200);
		setLayout(new BorderLayout());
		Image imagen = new ImageIcon("imagenes"+File.separator+"interrogacion.jpg").getImage();
		ImageIcon imagen2 = new ImageIcon(imagen.getScaledInstance(400, 380, Image.SCALE_SMOOTH));
		img=new JLabel(imagen2);
		img.getPreferredSize();
		
		panelCenRInf.setOpaque(true);
		panelCenRInf.setBackground(new Color(220,220,220));
		
		hp_bar = new JProgressBar(0,100);
		hp_bar.setPreferredSize(new Dimension(400,80));
		hp_bar.setValue(100);
		hp_bar.setForeground(Color.green);
		hp_bar.setStringPainted(true);
		
		setSize(420,500);
		add(hp_bar,BorderLayout.NORTH);
		add(img,BorderLayout.CENTER);
		add(panelCenRInf,BorderLayout.SOUTH);
	}
}
class PanelCenRInf extends JPanel{
	JPanel izq,der,cen;
	JLabel img;
	JList statsname, stats;
	JProgressBar str,def,agi,spd;
	public PanelCenRInf() {
		
		setSize(200, 200);
		izq = new JPanel();
		cen = new JPanel();
		der = new JPanel(new GridLayout(4,1));
		
		String[] info= {"Power","Agility","Speed","Defense"}; 
		statsname=new JList(info);
		statsname.setBackground(new Color(220,220,220));
		Image imagen = new ImageIcon("imagenes"+File.separator+"interrogacion.jpg").getImage();
		ImageIcon imagen2 = new ImageIcon(imagen.getScaledInstance(65, 50, Image.SCALE_SMOOTH));
		img=new JLabel(imagen2);
		img.getPreferredSize();
	
		izq.setOpaque(true);
		izq.setBackground(new Color(220,220,220));
		der.setOpaque(true);
		der.setBackground(new Color(220,220,220));
		cen.setOpaque(true);
		cen.setBackground(new Color(220,220,220));
		cen.setPreferredSize(new Dimension(100,0));
		
		izq.add(statsname);
		izq.add(img);
	
		
		str = new JProgressBar(0,11);
		str.setPreferredSize(new Dimension(140,18));
		str.setValue(5);
		str.setStringPainted(false);
		str.setForeground(Color.red);

		agi = new JProgressBar(0,11);
		agi.setPreferredSize(new Dimension(140,18));
		agi.setValue(5);
		agi.setStringPainted(false);
		agi.setForeground(new Color(153,50,204));
		
		def = new JProgressBar(0,11);
		def.setPreferredSize(new Dimension(140,18));
		def.setValue(5);
		def.setStringPainted(false);
		def.setForeground(Color.blue);
		
		spd = new JProgressBar(0,11);
		spd.setPreferredSize(new Dimension(140,18));
		spd.setValue(5);
		spd.setStringPainted(false);
		spd.setForeground(Color.yellow);
		
		der.add(str);
		der.add(agi);
		der.add(def);
		der.add(spd);
		
		add(der,BorderLayout.WEST);
		
		add(cen,BorderLayout.CENTER);
		add(izq,BorderLayout.EAST);
	}
}
//Inferior panel of Center Panel of Main Window "panelcen"
class PanelCenInf extends JPanel{
	JButton fight,clear;
	
	public PanelCenInf() {
		fight=new JButton("FIGHT");
		clear=new JButton("Clear Console");
		
		add(fight);
		add(clear);
	}
}

//Inferior panel of Main window "Main_Window"
class PanelInf extends JPanel{
	JScrollPane scrlbar;
	JTextArea cmndline;
	public PanelInf() {
		cmndline = new JTextArea(7,79);
		scrlbar = new JScrollPane(cmndline);
		cmndline.setEditable(false);
		add(scrlbar);
	}
}
