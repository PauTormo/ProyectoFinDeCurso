import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class ConnectionBDD {
	
	String url;
	String user;
	String pass;
	Connection con;
	
	public  ConnectionBDD() {
		try {
			// Connect to the BDD
			 
			 url="jdbc:mysql://localhost/project?serverTimezone=UTC";
			 user="root";
			 pass="admin";
			Class.forName("com.mysql.cj.jdbc.Driver");
			 con=DriverManager.getConnection(url, user, pass);
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public Connection getCon() {
		return con;
	}
	public void saveUser(String name) {
		ConnectionBDD con=new ConnectionBDD();
		Statement stm;
		try {
			stm = con.getCon().createStatement();
			String update ="insert into players (player_name) values (\""+name+"\");";
			stm.executeUpdate(update);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void saveBattle(Warriors war1,Weapons wea1,Warriors war2,Weapons wea2,int dmgcaused,int dmgsuffer,int points) {
		ConnectionBDD con=new ConnectionBDD();
		Statement stm;
		int userid=0;
		try {
			stm = con.getCon().createStatement();
			String query = "select player_id,player_name from players where player_id=(select max(player_id)\n" + 
							"from players);";
			ResultSet rs = stm.executeQuery(query);
			while (rs.next()) {
				userid= rs.getInt(1);
			}
			String update ="insert into battle (player_id,warrior_id,warrior_weapon_id,oponent_id,oponent_weapon_id,injuries_caused,injuries_suffered,battle_points)"
					+ " values ("+userid+","+war1.getId()+","+wea1.getIdWeapon()+","+war2.getId()+","+wea2.getIdWeapon()+","+dmgcaused
					+","+dmgsuffer+","+points+");";

			stm.executeUpdate(update);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public Integer getBtlId() {
		ConnectionBDD con=new ConnectionBDD();
		Statement stm;
		int batleId=0;
		try {
			stm = con.getCon().createStatement();
			String query ="select max(battle_id) from battle;";
			ResultSet rs = stm.executeQuery(query);
			while (rs.next()) {
				batleId= rs.getInt(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return batleId;
		
	}
	public Integer getUserId() {
		ConnectionBDD con=new ConnectionBDD();
		Statement stm;
		int playerId=0;
		try {
			stm = con.getCon().createStatement();
			String query ="select max(player_id) from players;";
			ResultSet rs = stm.executeQuery(query);
			while (rs.next()) {
				playerId= rs.getInt(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return playerId;
		
	}
	public String getUserName() {
		ConnectionBDD con=new ConnectionBDD();
		Statement stm;
		String playerName = "";
		try {
			stm = con.getCon().createStatement();
			String query ="select player_name from players where player_id=(select max(player_id) from players);";
			ResultSet rs = stm.executeQuery(query);
			while (rs.next()) {
				playerName= rs.getString(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return playerName;
		
	}
	public void setRanking(int player_id,int battle_points,Warriors war) {
		ConnectionBDD con=new ConnectionBDD();
		Statement stm;
		try {
			stm = con.getCon().createStatement();
			String update ="insert into ranking values("+player_id+","+battle_points+","+war.getId()+");";
			stm.executeUpdate(update);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
