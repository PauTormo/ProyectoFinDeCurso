import java.util.ArrayList;

import javax.swing.JProgressBar;
import javax.swing.JTextArea;

public class Fight_Main {
	Warriors fighter,block,swap,winner;
	Boolean hit;
	int dmg;
	int totalhp1,totalhp2;
	int btle_pnt;
	public Fight_Main(Warriors war1,Warriors war2, Weapons wea1, Weapons wea2,JProgressBar hp1,JProgressBar hp2,JTextArea cmd,ConnectionBDD con,int btl_pnt) {
		totalhp1=war1.getHp();
		totalhp2=war2.getHp();
		Luchar(war1,war2,wea2,wea2,hp1,hp2,cmd,con,btl_pnt);
	}
	public void Luchar(Warriors war1,Warriors war2, Weapons wea1, Weapons wea2,JProgressBar hp1,JProgressBar hp2,JTextArea cmd,ConnectionBDD con,int btl_pnt) {
		if (war1.getSpeed()+wea1.getSpeed()>war2.getSpeed()+wea2.getSpeed()) {
			fighter=war1;
			block=war2;
		}else if (war1.getSpeed()+wea1.getSpeed()<war2.getSpeed()+wea2.getSpeed()) {
			fighter=war2;
			block=war1;
		}else if (war1.getAgility()>war2.getAgility()) {
			fighter=war1;
			block=war2;
		}else if (war1.getAgility()<war2.getAgility()){
			fighter=war2;
			block=war1;
		}else {
			int numAleatorio = (int) (Math.random()*2);
			if (numAleatorio==0) {
				fighter=war1;
				block=war2;
			}else {
				fighter=war2;
				block=war1;
			}
		}
		
		
		while (war1.getHp()>0 && war2.getHp()>0) {
			if (fighter.getName().equals(war1.getName())) {
				dmg= fighter.getStrength()+wea1.getStrength();
			}else {
				dmg= fighter.getStrength()+wea2.getStrength();
			}
			
					
			int hitrate = (int) (Math.random()*9);
			
			
			if (fighter.getAgility()>hitrate) {
				int dodge = (int) (Math.random()*49);
				if (block.getDefense()>=dodge) {
					cmd.append(block.getName()+" avoid attack\n");
				}else {
					cmd.append(fighter.getName()+" has dealt "+dmg+" damage to the "+block.getName()+"\n");
					
					setHpBar(block,war1.getName(),war2.getName(),hp1,hp2,dmg,totalhp1,totalhp2);
				}
				if (fighter.getName().equals(war1.getName())) {
					if ((fighter.getSpeed()+wea1.getSpeed())>=(block.getSpeed()+wea2.getSpeed())) {
						
					}	
				}else {
					if ((fighter.getSpeed()+wea2.getSpeed())>=(block.getSpeed()+wea1.getSpeed())) {
						
					}
				}
				
			}else {
				cmd.append(fighter.getName()+" hit failed\n");
			}
			
			swap=fighter;
			fighter=block;
			block=swap;
		}
		
		int j = con.getBtlId();
		if (war1.getHp()>0) {
			btle_pnt=war2.getPoints()+wea2.getPoints();
			con.saveBattle(war1,wea1,war2,wea2,10000,5000,btle_pnt);
			
		}else {
			con.saveBattle(war1,wea1,war2,wea2,10000,5000,btle_pnt);
			con.setRanking(con.getUserId(),btl_pnt,war1);
			
			btle_pnt=0;
		}
	}
	public void setHpBar(Warriors war,String nom1,String nom2, JProgressBar hp1, JProgressBar hp2,int dmg,int totalhp1,int totalhp2) {
		
		String name= war.getName();
		
		int realdmg=100*dmg;
		int hplose1=realdmg/totalhp1;
		int hplose2=realdmg/totalhp2;
		
		int hp1now=hp1.getValue();
		int hp2now=hp2.getValue();
		
		if (name.equalsIgnoreCase(nom1)) {
			if ((war.getHp()-dmg)<=0) {
				hp1.setValue(0);
				war.setHp(0);
			}else {
				
				hp1.setValue(hp1now-hplose1);
				war.setHp(war.getHp()-dmg);
				
				
			}
			
		}else {
			if ((war.getHp()-dmg)<=0) {
				hp2.setValue(0);
				war.setHp(0);
				
			}else {
				
				hp2.setValue(hp2now-hplose2);
				war.setHp(war.getHp()-dmg);
				
				
			}
		}
	}
}

