


import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;


public class Character_Window extends JFrame implements ActionListener{
	String warriorSelect="";
	JButton images[];
	public Character_Window(ArrayList<Warriors> wp) {
		setLayout(new GridLayout(3,3));
		setSize(900,750);
		images=new JButton[wp.size()];
		int i=0;
		
		for(Warriors w : wp) {
			
			Image image = new ImageIcon("imagenes"+File.separator+"Warriors"+File.separator+w.getImagePath()).getImage();
			ImageIcon imageC1 = new ImageIcon(image.getScaledInstance(300, 250, Image.SCALE_SMOOTH));
			images[i]=new JButton(imageC1);
			images[i].getPreferredSize();
			images[i].setName(w.getName());
			add(images[i]);	
			images[i].addActionListener(this);
			i++;
			
		}
		for (int h = 0; h < images.length; h++) {
			int cont = h;
			images[cont].addMouseListener(new MouseAdapter() {
			
				@Override
				public void mouseClicked(MouseEvent arg0) {
					images[cont].setEnabled(false);
					for (int j = 0; j < images.length; j++) {
						if (!images[cont].getName().equalsIgnoreCase(images[j].getName())) {
							images[j].setEnabled(true);
						}
						
					}
					
				}
				
			});
		}
	
		setVisible(true);
		
		
	}
	
	 public void actionPerformed(ActionEvent e) {
	        if (e.getSource()==images[0]) {
	        	warriorSelect=images[0].getName();
	        }
	        if (e.getSource()==images[1]) {
	        	warriorSelect=images[1].getName(); 
	        }
	        if (e.getSource()==images[2]) {
	        	warriorSelect=images[2].getName();
	        }
	        if (e.getSource()==images[3]) {
	        	warriorSelect=images[3].getName(); 
	        }
	        if (e.getSource()==images[4]) {
	        	warriorSelect=images[4].getName();
	        }
	        if (e.getSource()==images[5]) {
	        	warriorSelect=images[5].getName(); 
	        }
	        if (e.getSource()==images[6]) {
	        	warriorSelect=images[6].getName();
	        }
	        if (e.getSource()==images[7]) {
	        	warriorSelect=images[7].getName(); 
	        }	
	        if (e.getSource()==images[8]) {
	        	warriorSelect=images[8].getName(); 
	        }		        
	    }
	 
	 public String getValor() {
		 return warriorSelect;
	 }
}
