
import java.sql.Connection;
import java.sql.DriverManager;

import java.sql.SQLException;

public class Proyect_Main {

	public static void main(String[] args) {
		//Creation of new User
		new User();
		
		//Open the entire program
		new Main_Window();
			
	}
}



