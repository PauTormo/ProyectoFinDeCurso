import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class WeaponContainer {
	private ArrayList<Weapons> aw=new ArrayList<Weapons>();
	WeaponContainer(){
		
	}
	
	public ArrayList<Weapons> createWeaponsContainer(ConnectionBDD connection, Warriors war) {
		//Read the database and load the weapons
			Weapons weapon;
			aw.clear();
				try {
					Statement stm = connection.getCon().createStatement();
					String query = "Select weapon_id, weapon_name, weapon_image_path, strength ,speed, weapon_race ,points \n"
							+ " from weapons;";
					ResultSet rs = stm.executeQuery(query);
					
			        while(rs.next()){
			        	String[] races= rs.getString(6).split(",");
			        	for (int i = 0; i < races.length; i++) {
			        		if (war.getRaceName().equals(races[i])) {
				        		weapon = new Weapons();
					        	weapon.setIdWeapon(rs.getInt(1));
					        	weapon.setWeaponName(rs.getString(2));
					        	weapon.setWeaponImagePath(rs.getString(3));
					        	weapon.setStrength(rs.getInt(4));
					        	weapon.setSpeed(rs.getInt(5));
					        	weapon.setWeaponRace(rs.getString(6));
					        	weapon.setPoints(rs.getInt(7));
					            aw.add(weapon);
					            break;
					            }
						}
			        }
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				

		return aw;
	}
	//Getters & Setters
	public ArrayList<Weapons> getAw() {
		return aw;
	}
	public void setAw(ArrayList<Weapons> aw) {
		this.aw = aw;
	}
}
