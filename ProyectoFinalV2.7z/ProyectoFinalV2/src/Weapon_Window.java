import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;


public class Weapon_Window extends JFrame implements ActionListener{
	//Array for the buttons 
	private JButton images[];
	private String weaponSelect="";
	public Weapon_Window(ArrayList<Weapons> aw) {
		setLayout(new GridLayout(3,3));
		setSize(900,750);
		
		images=new JButton[aw.size()];
		int i=0;

		for(Weapons w : aw) {
			//add image to the button according to its route
			Image image = new ImageIcon("imagenes"+File.separator+"Weapons"+File.separator+w.getWeaponImagePath()).getImage();
			ImageIcon imageC1 = new ImageIcon(image.getScaledInstance(300, 250, Image.SCALE_SMOOTH));
			images[i]=new JButton(imageC1);
			images[i].getPreferredSize();
			add(images[i]);	
			images[i].setName(w.getWeaponName());
			images[i].addActionListener(this);
			i++;
		}
		//the selected button will turn dark
		for (int h = 0; h < images.length; h++) {
			int cont = h;
			images[cont].addMouseListener(new MouseAdapter() {
			
				@Override
				public void mouseClicked(MouseEvent arg0) {
					images[cont].setEnabled(false);
					for (int j = 0; j < images.length; j++) {
						if (!images[cont].getName().equalsIgnoreCase(images[j].getName())) {
							images[j].setEnabled(true);
						}
						
					}
					
				}
				
			});
		}
		
		setVisible(true);
	}

public void actionPerformed(ActionEvent e) {
	for (int i = 0; i < images.length; i++) {
		if (e.getSource()==images[i]) {
	    	weaponSelect=images[i].getName();
	    	
	    }
	}
}


public String getValor() {
	return weaponSelect;
	}
	//Getters & Setters

public JButton[] getImages() {
	return images;
}

public void setImages(JButton[] images) {
	this.images = images;
}

public String getWeaponSelect() {
	return weaponSelect;
}

public void setWeaponSelect(String weaponSelect) {
	this.weaponSelect = weaponSelect;
}
	
}