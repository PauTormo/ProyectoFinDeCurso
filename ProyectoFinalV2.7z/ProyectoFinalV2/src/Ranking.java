import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRootPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class Ranking  extends JFrame{
	private JPanel panelUp,panelCen,panelLInv;
	private JTextArea tplayer,tpoints,twar,title;
	private JTextArea player,points,war;
	private JScrollPane scroll;
	
	private GridLayout grid;
	public Ranking(ConnectionBDD connection) {
		panelUp = new JPanel();
		panelLInv = new JPanel();
		panelLInv.setOpaque(true);
		panelLInv.setPreferredSize(new Dimension(210,0));
		grid = new GridLayout(6,3);
		panelUp.setPreferredSize(new Dimension(150,100));
		grid.setHgap(-50);
		grid.setVgap(-100);
		panelCen = new JPanel(grid);
		
		
		//Here we put the title in the ranking window
		title = new JTextArea("Ranking");
		title.setFont(new Font("Monospaced",Font.PLAIN,50));
		title.setOpaque(false);
		title.setBackground(new Color(255,255,255,255));
		
		//Here we configure the player id, points, and warrior in the ranking window
		tplayer = new JTextArea("Player Id");
		tplayer.setFont(new Font("Monospaced",Font.PLAIN,20));
		tplayer.setOpaque(false);
		tplayer.setBackground(new Color(255,255,255,255));
		tpoints = new JTextArea("Points");
		tpoints.setFont(new Font("Monospaced",Font.PLAIN,20));
		tpoints.setOpaque(false);
		tpoints.setBackground(new Color(255,255,255,255));
		twar = new JTextArea("Warrior Id");
		twar.setFont(new Font("Monospaced",Font.PLAIN,20));		
		twar.setOpaque(false);
		twar.setBackground(new Color(255,255,255,255));
		
		//Adding the player, points and war to the panel
		panelCen.add(tplayer);
		panelCen.add(tpoints);
		panelCen.add(twar);

		try {
			
			Statement stm = connection.getCon().createStatement();
			String query = "select * from ranking order by total_points desc limit 5;";
			ResultSet rs = stm.executeQuery(query);
	        while (rs.next()) {
	        	player = new JTextArea();
	    		player.setOpaque(false);
	    		player.setBackground(new Color(255,255,255,255));
	    		points = new JTextArea();
	    		points.setOpaque(false);
	    		points.setBackground(new Color(255,255,255,255));
	    		war = new JTextArea();
	    		war.setOpaque(false);
	    		war.setBackground(new Color(255,255,255,255));
	        	player.setText(String.valueOf(rs.getInt(1)));
	        	points.setText(String.valueOf(rs.getInt(2)));
	        	war.setText(String.valueOf(rs.getInt(3)));
	        	panelCen.add(player);
	    		panelCen.add(points);
	    		panelCen.add(war);
	        }
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		panelUp.add(title);
		
		
		add(panelUp,BorderLayout.NORTH);
		add(panelLInv,BorderLayout.WEST);
		add(panelCen,BorderLayout.CENTER);
		
		setSize(900,750);
		setVisible(true);
	}
	//Getters & Setters
	public JPanel getPanelUp() {
		return panelUp;
	}
	public void setPanelUp(JPanel panelUp) {
		this.panelUp = panelUp;
	}
	public JPanel getPanelCen() {
		return panelCen;
	}
	public void setPanelCen(JPanel panelCen) {
		this.panelCen = panelCen;
	}
	public JPanel getPanelLInv() {
		return panelLInv;
	}
	public void setPanelLInv(JPanel panelLInv) {
		this.panelLInv = panelLInv;
	}
	public JTextArea getTplayer() {
		return tplayer;
	}
	public void setTplayer(JTextArea tplayer) {
		this.tplayer = tplayer;
	}
	public JTextArea getTpoints() {
		return tpoints;
	}
	public void setTpoints(JTextArea tpoints) {
		this.tpoints = tpoints;
	}
	public JTextArea getTwar() {
		return twar;
	}
	public void setTwar(JTextArea twar) {
		this.twar = twar;
	}
	
	public void setTitle(JTextArea title) {
		this.title = title;
	}
	public JTextArea getPlayer() {
		return player;
	}
	public void setPlayer(JTextArea player) {
		this.player = player;
	}
	public JTextArea getPoints() {
		return points;
	}
	public void setPoints(JTextArea points) {
		this.points = points;
	}
	public JTextArea getWar() {
		return war;
	}
	public void setWar(JTextArea war) {
		this.war = war;
	}
	public JScrollPane getScroll() {
		return scroll;
	}
	public void setScroll(JScrollPane scroll) {
		this.scroll = scroll;
	}
	public GridLayout getGrid() {
		return grid;
	}
	public void setGrid(GridLayout grid) {
		this.grid = grid;
	}
	
}

