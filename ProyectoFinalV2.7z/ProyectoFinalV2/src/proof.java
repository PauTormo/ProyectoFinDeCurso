import javax.swing.JOptionPane;

public class proof {

	public static void main(String[] args) {
		int input = JOptionPane.showOptionDialog(null,"If you change the character now, your battle point will be restarted\n Are you sure to continue?", "Continue?",
				JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null,null,null);
		System.out.println(input);
	}

}
