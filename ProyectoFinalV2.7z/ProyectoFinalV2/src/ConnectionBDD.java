import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class ConnectionBDD {
	
	private String url;
	private String user;
	private String pass;
	private Connection con;
	//Metod to connect to Data Base in the entire project
	public  ConnectionBDD() {
		try {
			// Connect to the Data Base
			 
			 url="jdbc:mysql://localhost/project?serverTimezone=UTC";
			 user="alumne";
			 pass="alumne";
			Class.forName("com.mysql.cj.jdbc.Driver");
			 con=DriverManager.getConnection(url, user, pass);
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	//Metod to get the connexion
	public Connection getCon() {
		return con;
	}
	
	//Metod to save the actual user to the Data Base
	public void saveUser(String name) {
		ConnectionBDD con=new ConnectionBDD();
		Statement stm;
		try {
			stm = con.getCon().createStatement();
			String update ="insert into players (player_name) values (\""+name+"\");";
			stm.executeUpdate(update);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	//Metod to save the Battle
	public void saveBattle(Warriors war1,Weapons wea1,Warriors war2,Weapons wea2,int dmgcaused,int dmgsuffer,int points) {
		ConnectionBDD con=new ConnectionBDD();
		Statement stm;
		int userid=0;
		try {
			stm = con.getCon().createStatement();
			String query = "select player_id,player_name from players where player_id=(select max(player_id)\n" + 
							"from players);";
			ResultSet rs = stm.executeQuery(query);
			while (rs.next()) {
				userid= rs.getInt(1);
			}
			String update ="insert into battle (player_id,warrior_id,warrior_weapon_id,oponent_id,oponent_weapon_id,injuries_caused,injuries_suffered,battle_points)"
					+ " values ("+userid+","+war1.getId()+","+wea1.getIdWeapon()+","+war2.getId()+","+wea2.getIdWeapon()+","+dmgcaused
					+","+dmgsuffer+","+points+");";

			stm.executeUpdate(update);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	//Metod to get the last battle_id
	public Integer getBtlId() {
		ConnectionBDD con=new ConnectionBDD();
		Statement stm;
		int batleId=0;
		try {
			stm = con.getCon().createStatement();
			String query ="select max(battle_id) from battle;";
			ResultSet rs = stm.executeQuery(query);
			while (rs.next()) {
				batleId= rs.getInt(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return batleId;
		
	}
	
	//Metod to get the last user id
	public Integer getUserId() {
		ConnectionBDD con=new ConnectionBDD();
		Statement stm;
		int playerId=0;
		try {
			stm = con.getCon().createStatement();
			String query ="select max(player_id) from players;";
			ResultSet rs = stm.executeQuery(query);
			while (rs.next()) {
				playerId= rs.getInt(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return playerId;
		
	}
	
	//Metod to get the last user name
	public String getUserName() {
		ConnectionBDD con=new ConnectionBDD();
		Statement stm;
		String playerName = "";
		try {
			stm = con.getCon().createStatement();
			String query ="select player_name from players where player_id=(select max(player_id) from players);";
			ResultSet rs = stm.executeQuery(query);
			while (rs.next()) {
				playerName= rs.getString(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return playerName;
		
	}
	
	//Metod to save the last gameon the ranking
	public void setRanking(int player_id,int battle_points,Warriors war) {
		ConnectionBDD con=new ConnectionBDD();
		Statement stm;
		try {
			stm = con.getCon().createStatement();
			String update ="insert into ranking values("+player_id+","+battle_points+","+war.getId()+");";
			stm.executeUpdate(update);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	//Getters & Setters

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}

	public void setCon(Connection con) {
		this.con = con;
	}
	
}
