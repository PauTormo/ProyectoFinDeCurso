import java.util.ArrayList;

import javax.swing.JProgressBar;
import javax.swing.JTextArea;

public class Fight_Main {
	private Warriors fighter,block,swap,winner;
	private Boolean hit;
	private int dmg;
	private int totalhp1,totalhp2;
	private int btle_pnt;
	//Constructor of the fight
	public Fight_Main(Warriors war1,Warriors war2, Weapons wea1, Weapons wea2,JProgressBar hp1,JProgressBar hp2,JTextArea cmd,ConnectionBDD con,int btl_pnt) {
		totalhp1=war1.getHp();
		totalhp2=war2.getHp();
		//If we are playing against the same warrior we change the name of warrior 2 to can difference the warriors
		if (war1.getName().equals(war2.getName())) {
			war2.setName(war2.getName()+"_Bot");
		}
		Luchar(war1,war2,wea2,wea2,hp1,hp2,cmd,con,btl_pnt);
	}
	//Metod that start the battle
	public void Luchar(Warriors war1,Warriors war2, Weapons wea1, Weapons wea2,JProgressBar hp1,JProgressBar hp2,JTextArea cmd,ConnectionBDD con,int btl_pnt) {
		
		//In this block of if we choose who is the first attacker and who is the blocker
		if (war1.getSpeed()+wea1.getSpeed()>war2.getSpeed()+wea2.getSpeed()) {
			fighter=war1;
			block=war2;
		}else if (war1.getSpeed()+wea1.getSpeed()<war2.getSpeed()+wea2.getSpeed()) {
			fighter=war2;
			block=war1;
		}else if (war1.getAgility()>war2.getAgility()) {
			fighter=war1;
			block=war2;
		}else if (war1.getAgility()<war2.getAgility()){
			fighter=war2;
			block=war1;
		}else {
			int numAleatorio = (int) (Math.random()*2);
			if (numAleatorio==0) {
				fighter=war1;
				block=war2;
			}else {
				fighter=war2;
				block=war1;
			}
		}
		
		//At this point start the battle if two warriors we've passed have more than 0 HP
		while (war1.getHp()>0 && war2.getHp()>0) {
			if (fighter.getName().equals(war1.getName())) {
				dmg= fighter.getStrength()+wea1.getStrength();
			}else {
				dmg= fighter.getStrength()+wea2.getStrength();
			}
			cmd.append("Turn of "+fighter.getName()+"!\n\n");
					
			int hitrate = (int) (Math.random()*9);
			
			//Firts hit from fighter to blocker
			if (fighter.getAgility()>hitrate) {
				int dodge = (int) (Math.random()*49);
				if (block.getAgility()>=dodge) {
					cmd.append(fighter.getName()+" goes to hit "+block.getName()+"\n");
					cmd.append("But "+block.getName()+" avoids attack\n\n");
				}else {
					cmd.append(fighter.getName()+" has dealt "+dmg+" damage to the "+block.getName()+"\n\n");
					setHpBar(block,war1.getName(),war2.getName(),hp1,hp2,dmg,totalhp1,totalhp2);
				}
								
			}else {
				cmd.append(fighter.getName()+" hit failed\n\n");
			}
			
			//With stats of warriors and random numbers, choose if the fighter attacks another time or not
			int aleato=((fighter.getSpeed()+wea1.getSpeed())-(block.getSpeed()+wea2.getSpeed()))*10;
			int anotherAtt = (int) (Math.random()*aleato);
			int change = (int) (Math.random()*aleato);
			int cont=0;
			if (fighter.getName().equals(war1.getName())) {
				if ((fighter.getSpeed()+wea1.getSpeed())<=(block.getSpeed()+wea2.getSpeed())) {
					if (anotherAtt>change && war1.getHp()>0 && war2.getHp()>0) {
						cmd.append(fighter.getName()+" attacks another time!\n\n");
						cont+=1;
					}
				}
			}else {
				if ((fighter.getSpeed()+wea2.getSpeed())<=(block.getSpeed()+wea1.getSpeed())) {
					if (anotherAtt>change && war1.getHp()>0 && war2.getHp()>0) {
						cmd.append(fighter.getName()+" attacks another time!\n\n");
						cont+=1;
					}						
				}
			}
			// Before while ends, swap the attacker to blocker and swap the blocker to attacker
			if (cont==0 && war1.getHp()>0 && war2.getHp()>0) {
				swap=fighter;
				fighter=block;
				block=swap;
			}
			
		}
		// If the war 1 that is our war have more than 0 hp when the fight has end, we add the battle points and save this battle to Data Base
		if (war1.getHp()>0) {
			btle_pnt=war2.getPoints()+wea2.getPoints();
			con.saveBattle(war1,wea1,war2,wea2,10000,5000,btle_pnt);
			
		}else {
		//if the war 1 that is our war have less than 0 hp, we save the fight in Data Base with current battle points,
		//we add the ranking of this game in data base
		//and we restart the battle point to 0 because the game has ended because war 1 has lose
			con.saveBattle(war1,wea1,war2,wea2,10000,5000,btle_pnt);
			con.setRanking(con.getUserId(),btl_pnt,war1);
			
			btle_pnt=0;
		}
	}
	//Metod who set the HpBar of the warriors in the battle
	public void setHpBar(Warriors war,String nom1,String nom2, JProgressBar hp1, JProgressBar hp2,int dmg,int totalhp1,int totalhp2) {
		
		String name= war.getName();
		
		int realdmg=100*dmg;
		int hplose1=realdmg/totalhp1;
		int hplose2=realdmg/totalhp2;
		
		int hp1now=hp1.getValue();
		int hp2now=hp2.getValue();
		
		if (name.equalsIgnoreCase(nom1)) {
			if ((war.getHp()-dmg)<=0) {
				hp1.setValue(0);
				war.setHp(0);
			}else {
				
				hp1.setValue(hp1now-hplose1);
				war.setHp(war.getHp()-dmg);
				
				
			}
			
		}else {
			if ((war.getHp()-dmg)<=0) {
				hp2.setValue(0);
				war.setHp(0);
				
			}else {
				
				hp2.setValue(hp2now-hplose2);
				war.setHp(war.getHp()-dmg);
				
				
			}
		}
	}
	//Getters & Setters
	public Warriors getFighter() {
		return fighter;
	}
	public void setFighter(Warriors fighter) {
		this.fighter = fighter;
	}
	public Warriors getBlock() {
		return block;
	}
	public void setBlock(Warriors block) {
		this.block = block;
	}
	public Warriors getSwap() {
		return swap;
	}
	public void setSwap(Warriors swap) {
		this.swap = swap;
	}
	public Warriors getWinner() {
		return winner;
	}
	public void setWinner(Warriors winner) {
		this.winner = winner;
	}
	public Boolean getHit() {
		return hit;
	}
	public void setHit(Boolean hit) {
		this.hit = hit;
	}
	public int getDmg() {
		return dmg;
	}
	public void setDmg(int dmg) {
		this.dmg = dmg;
	}
	public int getTotalhp1() {
		return totalhp1;
	}
	public void setTotalhp1(int totalhp1) {
		this.totalhp1 = totalhp1;
	}
	public int getTotalhp2() {
		return totalhp2;
	}
	public void setTotalhp2(int totalhp2) {
		this.totalhp2 = totalhp2;
	}
	public int getBtle_pnt() {
		return btle_pnt;
	}
	public void setBtle_pnt(int btle_pnt) {
		this.btle_pnt = btle_pnt;
	}
	
}

