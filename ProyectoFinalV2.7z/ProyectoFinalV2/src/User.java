import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class User extends JFrame{
	private JFrame f, fail;
	private ConnectionBDD con;
	private String name;
	
	//Window for entering user name
	public User() {
		con=new ConnectionBDD();
		do {
			f=new JFrame();   
		    name=JOptionPane.showInputDialog(f,"Enter Name","Guest");
		    //If the name is empty, he asks you again
		    if (name==null || name.equalsIgnoreCase("")) {
			    JOptionPane.showMessageDialog(fail,"The name can only contain letters");
				name="Error";
			}
		    
		    for (int i = 0; i < name.length(); i++)
			{
				char caracter = name.toUpperCase().charAt(i);
				int valorASCII = (int)caracter;
				//If the name has special characters it asks you again
				if (valorASCII != 165 && (valorASCII < 65 || valorASCII > 90)) {
					JOptionPane.showMessageDialog(fail,"The name can only contain letters");
					name="Error";
					
				}
			}
		    
		} while (name.equalsIgnoreCase("Error"));
		
	    con.saveUser(name);
	    
	}
	//Getters & Setters
	public JFrame getF() {
		return f;
	}
	public void setF(JFrame f) {
		this.f = f;
	}
	public ConnectionBDD getCon() {
		return con;
	}
	public void setCon(ConnectionBDD con) {
		this.con = con;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
}